import { useState } from 'react';
import { Home } from './components/Home';
import { MovieDetails } from './components/MovieDetails';
import { Search } from './components/Search';
import { Categories } from './components/Categories';
import { BottomNav } from './components/BottomNav';

export type MediaType = 'movie' | 'series';

export interface Media {
  id: number;
  title: string;
  type: MediaType;
  year: number;
  rating: number;
  duration: string;
  genre: string[];
  description: string;
  imageUrl: string;
  backdrop: string;
}

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'search' | 'categories' | 'details'>('home');
  const [selectedMedia, setSelectedMedia] = useState<Media | null>(null);

  const handleMediaClick = (media: Media) => {
    setSelectedMedia(media);
    setCurrentView('details');
  };

  const handleBack = () => {
    setCurrentView('home');
    setSelectedMedia(null);
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <Home onMediaClick={handleMediaClick} />;
      case 'search':
        return <Search onMediaClick={handleMediaClick} />;
      case 'categories':
        return <Categories onMediaClick={handleMediaClick} />;
      case 'details':
        return selectedMedia ? (
          <MovieDetails media={selectedMedia} onBack={handleBack} />
        ) : null;
      default:
        return <Home onMediaClick={handleMediaClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-black pb-16">
      {renderView()}
      {currentView !== 'details' && (
        <BottomNav currentView={currentView} onNavigate={setCurrentView} />
      )}
    </div>
  );
}
