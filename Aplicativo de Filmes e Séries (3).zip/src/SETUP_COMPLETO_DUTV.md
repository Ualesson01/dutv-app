# 🎬 DuTV - Setup Completo

## 📦 INSTRUÇÕES DE INSTALAÇÃO

### 1. Crie uma pasta chamada `dutv-app`

### 2. Dentro dela, crie a seguinte estrutura:

```
dutv-app/
├── public/
├── src/
│   ├── components/
│   │   └── ui/
│   ├── services/
│   ├── data/
│   └── styles/
```

### 3. Copie cada arquivo abaixo para sua respectiva pasta

---

## 📄 ARQUIVO: `package.json` (raiz)

```json
{
  "name": "dutv",
  "version": "1.0.0",
  "description": "DuTV - Aplicativo de Filmes e Séries",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "latest",
    "@radix-ui/react-slot": "^1.0.2",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.0.0",
    "typescript": "^5.0.0",
    "vite": "^5.0.0",
    "vite-plugin-pwa": "^0.17.0",
    "tailwindcss": "^4.0.0"
  }
}
```

---

## 📄 ARQUIVO: `index.html` (raiz)

```html
<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="DuTV - Seu app de filmes e séries com conteúdo do TMDB" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="DuTV" />
    
    <link rel="manifest" href="/manifest.json" />
    
    <title>DuTV - Filmes e Séries</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

---

## 📄 ARQUIVO: `vite.config.ts` (raiz)

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'DuTV - Filmes e Séries',
        short_name: 'DuTV',
        description: 'Seu app de filmes e séries com conteúdo do TMDB',
        theme_color: '#DC2626',
        background_color: '#000000',
        display: 'standalone',
        orientation: 'portrait'
      }
    })
  ],
  server: {
    port: 3000
  }
});
```

---

## 📄 ARQUIVO: `tsconfig.json` (raiz)

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

---

## 📄 ARQUIVO: `tsconfig.node.json` (raiz)

```json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
```

---

## 📄 ARQUIVO: `public/manifest.json`

```json
{
  "name": "DuTV - Filmes e Séries",
  "short_name": "DuTV",
  "description": "Seu app de filmes e séries com conteúdo do TMDB",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#000000",
  "theme_color": "#DC2626",
  "orientation": "portrait"
}
```

---

## 📄 ARQUIVO: `src/main.tsx`

```typescript
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

---

## 📄 ARQUIVO: `src/App.tsx`

```typescript
import { useState } from 'react';
import { Home } from './components/Home';
import { MovieDetails } from './components/MovieDetails';
import { Search } from './components/Search';
import { Categories } from './components/Categories';
import { BottomNav } from './components/BottomNav';

export type MediaType = 'movie' | 'series';

export interface Media {
  id: number;
  title: string;
  type: MediaType;
  year: number;
  rating: number;
  duration: string;
  genre: string[];
  description: string;
  imageUrl: string;
  backdrop: string;
}

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'search' | 'categories' | 'details'>('home');
  const [selectedMedia, setSelectedMedia] = useState<Media | null>(null);

  const handleMediaClick = (media: Media) => {
    setSelectedMedia(media);
    setCurrentView('details');
  };

  const handleBack = () => {
    setCurrentView('home');
    setSelectedMedia(null);
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <Home onMediaClick={handleMediaClick} />;
      case 'search':
        return <Search onMediaClick={handleMediaClick} />;
      case 'categories':
        return <Categories onMediaClick={handleMediaClick} />;
      case 'details':
        return selectedMedia ? (
          <MovieDetails media={selectedMedia} onBack={handleBack} />
        ) : null;
      default:
        return <Home onMediaClick={handleMediaClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-black pb-16">
      {renderView()}
      {currentView !== 'details' && (
        <BottomNav currentView={currentView} onNavigate={setCurrentView} />
      )}
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/services/tmdb.ts`

```typescript
import { Media } from '../App';

const TMDB_API_KEY = '3f70231d1356c2cdc9fe0fce9419c773';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';

interface TMDBMovie {
  id: number;
  title?: string;
  name?: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  genre_ids: number[];
  overview: string;
  poster_path: string;
  backdrop_path: string;
  media_type?: string;
}

interface TMDBGenre {
  id: number;
  name: string;
}

const genreMap: { [key: number]: string } = {
  28: 'Ação',
  12: 'Aventura',
  16: 'Animação',
  35: 'Comédia',
  80: 'Crime',
  99: 'Documentário',
  18: 'Drama',
  10751: 'Família',
  14: 'Fantasia',
  36: 'História',
  27: 'Terror',
  10402: 'Música',
  9648: 'Mistério',
  10749: 'Romance',
  878: 'Ficção Científica',
  10770: 'Cinema TV',
  53: 'Suspense',
  10752: 'Guerra',
  37: 'Faroeste',
  10759: 'Ação e Aventura',
  10762: 'Kids',
  10763: 'Notícias',
  10764: 'Reality',
  10765: 'Sci-Fi & Fantasy',
  10766: 'Novela',
  10767: 'Talk Show',
  10768: 'Guerra & Política',
};

function convertTMDBToMedia(item: TMDBMovie, type: 'movie' | 'series'): Media {
  const title = item.title || item.name || 'Sem título';
  const year = item.release_date
    ? new Date(item.release_date).getFullYear()
    : item.first_air_date
    ? new Date(item.first_air_date).getFullYear()
    : 2024;
  
  const genres = item.genre_ids
    .map(id => genreMap[id])
    .filter(Boolean)
    .slice(0, 3);

  return {
    id: item.id,
    title,
    type,
    year,
    rating: Math.round(item.vote_average * 10) / 10,
    duration: type === 'movie' ? '2h' : '1 temporada',
    genre: genres,
    description: item.overview || 'Descrição não disponível.',
    imageUrl: item.poster_path
      ? `${TMDB_IMAGE_BASE_URL}/w500${item.poster_path}`
      : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=500',
    backdrop: item.backdrop_path
      ? `${TMDB_IMAGE_BASE_URL}/original${item.backdrop_path}`
      : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=1920',
  };
}

async function fetchFromTMDB(endpoint: string): Promise<any> {
  const url = `${TMDB_BASE_URL}${endpoint}${endpoint.includes('?') ? '&' : '?'}api_key=${TMDB_API_KEY}&language=pt-BR`;
  
  const response = await fetch(url);
  
  if (!response.ok) {
    throw new Error(`TMDB API Error: ${response.status}`);
  }
  
  return response.json();
}

export async function getTrending(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/trending/all/week');
    return data.results.map((item: TMDBMovie) => 
      convertTMDBToMedia(item, item.media_type === 'tv' ? 'series' : 'movie')
    );
  } catch (error) {
    console.error('Error fetching trending:', error);
    return [];
  }
}

export async function getPopularMovies(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/movie/popular');
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'movie'));
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    return [];
  }
}

export async function getPopularSeries(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/tv/popular');
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'series'));
  } catch (error) {
    console.error('Error fetching popular series:', error);
    return [];
  }
}

export async function getMoviesByGenre(genreId: number): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/discover/movie?with_genres=${genreId}`);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'movie'));
  } catch (error) {
    console.error('Error fetching movies by genre:', error);
    return [];
  }
}

export async function getSeriesByGenre(genreId: number): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/discover/tv?with_genres=${genreId}`);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'series'));
  } catch (error) {
    console.error('Error fetching series by genre:', error);
    return [];
  }
}

export async function searchMedia(query: string): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/search/multi?query=${encodeURIComponent(query)}`);
    return data.results
      .filter((item: TMDBMovie) => item.media_type === 'movie' || item.media_type === 'tv')
      .map((item: TMDBMovie) => 
        convertTMDBToMedia(item, item.media_type === 'tv' ? 'series' : 'movie')
      );
  } catch (error) {
    console.error('Error searching media:', error);
    return [];
  }
}

export async function getMediaDetails(id: number, type: 'movie' | 'series'): Promise<Media | null> {
  try {
    const endpoint = type === 'movie' ? `/movie/${id}` : `/tv/${id}`;
    const data = await fetchFromTMDB(endpoint);
    
    const title = data.title || data.name || 'Sem título';
    const year = data.release_date
      ? new Date(data.release_date).getFullYear()
      : data.first_air_date
      ? new Date(data.first_air_date).getFullYear()
      : 2024;
    
    const genres = data.genres?.map((g: TMDBGenre) => g.name) || [];
    
    const duration = type === 'movie'
      ? data.runtime
        ? `${Math.floor(data.runtime / 60)}h ${data.runtime % 60}min`
        : '2h'
      : data.number_of_seasons
      ? `${data.number_of_seasons} ${data.number_of_seasons === 1 ? 'temporada' : 'temporadas'}`
      : '1 temporada';

    return {
      id: data.id,
      title,
      type,
      year,
      rating: Math.round(data.vote_average * 10) / 10,
      duration,
      genre: genres,
      description: data.overview || 'Descrição não disponível.',
      imageUrl: data.poster_path
        ? `${TMDB_IMAGE_BASE_URL}/w500${data.poster_path}`
        : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=500',
      backdrop: data.backdrop_path
        ? `${TMDB_IMAGE_BASE_URL}/original${data.backdrop_path}`
        : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=1920',
    };
  } catch (error) {
    console.error('Error fetching media details:', error);
    return null;
  }
}

export async function getSimilarMedia(id: number, type: 'movie' | 'series'): Promise<Media[]> {
  try {
    const endpoint = type === 'movie' ? `/movie/${id}/similar` : `/tv/${id}/similar`;
    const data = await fetchFromTMDB(endpoint);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, type));
  } catch (error) {
    console.error('Error fetching similar media:', error);
    return [];
  }
}

export const genreIds = {
  action: 28,
  comedy: 35,
  drama: 18,
  scifi: 878,
  thriller: 53,
  romance: 10749,
  animation: 16,
  documentary: 99,
};
```

---

## 📄 ARQUIVO: `src/components/Home.tsx`

```typescript
import { Media } from '../App';
import { MediaCarousel } from './MediaCarousel';
import { FeaturedBanner } from './FeaturedBanner';
import { useEffect, useState } from 'react';
import {
  getTrending,
  getPopularMovies,
  getPopularSeries,
  getMoviesByGenre,
  genreIds,
} from '../services/tmdb';

interface HomeProps {
  onMediaClick: (media: Media) => void;
}

export function Home({ onMediaClick }: HomeProps) {
  const [trending, setTrending] = useState<Media[]>([]);
  const [movies, setMovies] = useState<Media[]>([]);
  const [series, setSeries] = useState<Media[]>([]);
  const [action, setAction] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const [trendingData, moviesData, seriesData, actionData] = await Promise.all([
          getTrending(),
          getPopularMovies(),
          getPopularSeries(),
          getMoviesByGenre(genreIds.action),
        ]);

        setTrending(trendingData.slice(0, 8));
        setMovies(moviesData.slice(0, 8));
        setSeries(seriesData.slice(0, 8));
        setAction(actionData.slice(0, 8));
      } catch (error) {
        console.error('Error loading home data:', error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const featured = trending[0];

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Carregando...</div>
      </div>
    );
  }

  if (!featured) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-center px-4">
          <p className="mb-2">Erro ao carregar conteúdo</p>
          <p className="text-sm text-gray-400">Verifique sua chave de API do TMDB</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <FeaturedBanner media={featured} onPlay={() => onMediaClick(featured)} />
      
      <div className="px-4 space-y-6 -mt-20 relative z-10">
        {trending.length > 0 && (
          <MediaCarousel
            title="Em Alta"
            media={trending}
            onMediaClick={onMediaClick}
          />
        )}
        
        {movies.length > 0 && (
          <MediaCarousel
            title="Filmes Populares"
            media={movies}
            onMediaClick={onMediaClick}
          />
        )}
        
        {series.length > 0 && (
          <MediaCarousel
            title="Séries em Destaque"
            media={series}
            onMediaClick={onMediaClick}
          />
        )}
        
        {action.length > 0 && (
          <MediaCarousel
            title="Ação e Aventura"
            media={action}
            onMediaClick={onMediaClick}
          />
        )}
      </div>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/FeaturedBanner.tsx`

```typescript
import { Play, Info } from 'lucide-react';
import { Media } from '../App';
import { Button } from './ui/button';

interface FeaturedBannerProps {
  media: Media;
  onPlay: () => void;
}

export function FeaturedBanner({ media, onPlay }: FeaturedBannerProps) {
  return (
    <div className="relative h-[500px] w-full">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${media.backdrop})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <span className="px-2 py-1 bg-red-600 rounded">{media.type === 'movie' ? 'FILME' : 'SÉRIE'}</span>
          <span>{media.year}</span>
          <span>•</span>
          <span>{media.duration}</span>
        </div>
        
        <h1 className="text-white max-w-md">{media.title}</h1>
        
        <p className="text-gray-300 text-sm max-w-md line-clamp-3">
          {media.description}
        </p>
        
        <div className="flex gap-3">
          <Button className="flex-1 bg-white text-black hover:bg-gray-200" onClick={onPlay}>
            <Play className="w-5 h-5 mr-2 fill-current" />
            Assistir
          </Button>
          <Button variant="outline" className="flex-1 bg-gray-800/80 text-white border-gray-600 hover:bg-gray-700" onClick={onPlay}>
            <Info className="w-5 h-5 mr-2" />
            Detalhes
          </Button>
        </div>
      </div>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/MediaCarousel.tsx`

```typescript
import { Media } from '../App';
import { MediaCard } from './MediaCard';

interface MediaCarouselProps {
  title: string;
  media: Media[];
  onMediaClick: (media: Media) => void;
}

export function MediaCarousel({ title, media, onMediaClick }: MediaCarouselProps) {
  return (
    <div className="space-y-3">
      <h2 className="text-white px-1">{title}</h2>
      
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
        {media.map((item) => (
          <MediaCard
            key={item.id}
            media={item}
            onClick={() => onMediaClick(item)}
          />
        ))}
      </div>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/MediaCard.tsx`

```typescript
import { Star } from 'lucide-react';
import { Media } from '../App';

interface MediaCardProps {
  media: Media;
  onClick: () => void;
}

export function MediaCard({ media, onClick }: MediaCardProps) {
  return (
    <div
      className="flex-shrink-0 w-32 cursor-pointer transition-transform hover:scale-105"
      onClick={onClick}
    >
      <div className="relative rounded-lg overflow-hidden bg-gray-800 aspect-[2/3]">
        <img
          src={media.imageUrl}
          alt={media.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-black/70 px-2 py-1 rounded flex items-center gap-1">
          <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
          <span className="text-white text-xs">{media.rating}</span>
        </div>
      </div>
      <p className="text-white text-sm mt-2 line-clamp-2">{media.title}</p>
      <p className="text-gray-400 text-xs">{media.year}</p>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/MovieDetails.tsx`

```typescript
import { ArrowLeft, Play, Plus, Share2, Star } from 'lucide-react';
import { Media } from '../App';
import { Button } from './ui/button';
import { MediaCard } from './MediaCard';
import { useEffect, useState } from 'react';
import { getMediaDetails, getSimilarMedia } from '../services/tmdb';

interface MovieDetailsProps {
  media: Media;
  onBack: () => void;
}

export function MovieDetails({ media: initialMedia, onBack }: MovieDetailsProps) {
  const [media, setMedia] = useState(initialMedia);
  const [similar, setSimilar] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDetails() {
      setLoading(true);
      try {
        const [detailsData, similarData] = await Promise.all([
          getMediaDetails(initialMedia.id, initialMedia.type),
          getSimilarMedia(initialMedia.id, initialMedia.type),
        ]);

        if (detailsData) {
          setMedia(detailsData);
        }
        setSimilar(similarData.slice(0, 6));
      } catch (error) {
        console.error('Error loading details:', error);
      } finally {
        setLoading(false);
      }
    }

    loadDetails();
  }, [initialMedia.id, initialMedia.type]);

  return (
    <div className="min-h-screen bg-black">
      <div className="relative">
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-20 p-2 bg-black/50 rounded-full text-white"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        <div className="relative h-[300px]">
          <img
            src={media.backdrop}
            alt={media.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        </div>
        
        <div className="relative -mt-16 px-6 space-y-4">
          <h1 className="text-white">{media.title}</h1>
          
          <div className="flex items-center gap-3 text-sm text-gray-300">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span>{media.rating}</span>
            </div>
            <span>•</span>
            <span>{media.year}</span>
            <span>•</span>
            <span>{media.duration}</span>
            <span>•</span>
            <span className="px-2 py-0.5 bg-gray-700 rounded text-xs">
              {media.type === 'movie' ? 'FILME' : 'SÉRIE'}
            </span>
          </div>
          
          {media.genre.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {media.genre.map((g, i) => (
                <span key={i} className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm">
                  {g}
                </span>
              ))}
            </div>
          )}
          
          <p className="text-gray-300 text-sm leading-relaxed">
            {media.description}
          </p>
          
          <div className="space-y-3 pt-4">
            <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
              <Play className="w-5 h-5 mr-2 fill-current" />
              Assistir Agora
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                <Plus className="w-5 h-5 mr-2" />
                Minha Lista
              </Button>
              <Button variant="outline" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                <Share2 className="w-5 h-5 mr-2" />
                Compartilhar
              </Button>
            </div>
          </div>
          
          {similar.length > 0 && (
            <div className="pt-8 space-y-3">
              <h2 className="text-white">Títulos Similares</h2>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-4">
                {similar.map((item) => (
                  <MediaCard
                    key={item.id}
                    media={item}
                    onClick={() => {}}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/Search.tsx`

```typescript
import { useState, useEffect } from 'react';
import { SearchIcon, X } from 'lucide-react';
import { Media } from '../App';
import { searchMedia, getTrending } from '../services/tmdb';
import { MediaCard } from './MediaCard';

interface SearchProps {
  onMediaClick: (media: Media) => void;
}

export function Search({ onMediaClick }: SearchProps) {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Media[]>([]);
  const [popular, setPopular] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadPopular() {
      const data = await getTrending();
      setPopular(data.slice(0, 9));
    }
    loadPopular();
  }, []);

  useEffect(() => {
    const delaySearch = setTimeout(async () => {
      if (query.trim()) {
        setLoading(true);
        const results = await searchMedia(query);
        setSearchResults(results);
        setLoading(false);
      } else {
        setSearchResults([]);
      }
    }, 500);

    return () => clearTimeout(delaySearch);
  }, [query]);

  return (
    <div className="min-h-screen bg-black p-4">
      <div className="sticky top-0 bg-black pb-4 z-10">
        <h1 className="text-white mb-4">Buscar</h1>
        
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Filmes, séries, gêneros..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-gray-900 text-white pl-11 pr-11 py-3 rounded-lg outline-none focus:ring-2 focus:ring-red-600"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-800 rounded-full"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-16">
          <p className="text-gray-400">Buscando...</p>
        </div>
      ) : query.trim() ? (
        searchResults.length > 0 ? (
          <div className="grid grid-cols-3 gap-3 pt-4">
            {searchResults.map((media) => (
              <MediaCard
                key={media.id}
                media={media}
                onClick={() => onMediaClick(media)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-gray-400">Nenhum resultado encontrado para "{query}"</p>
          </div>
        )
      ) : (
        <div className="space-y-6 pt-4">
          <div>
            <h2 className="text-white mb-3">Populares</h2>
            <div className="grid grid-cols-3 gap-3">
              {popular.map((media) => (
                <MediaCard
                  key={media.id}
                  media={media}
                  onClick={() => onMediaClick(media)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/Categories.tsx`

```typescript
import { useState, useEffect } from 'react';
import { Media } from '../App';
import {
  getTrending,
  getPopularMovies,
  getPopularSeries,
  getMoviesByGenre,
  getSeriesByGenre,
  genreIds,
} from '../services/tmdb';
import { MediaCard } from './MediaCard';

interface CategoriesProps {
  onMediaClick: (media: Media) => void;
}

const categories = [
  { id: 'all', name: 'Todos' },
  { id: 'movies', name: 'Filmes' },
  { id: 'series', name: 'Séries' },
  { id: 'action', name: 'Ação' },
  { id: 'comedy', name: 'Comédia' },
  { id: 'drama', name: 'Drama' },
  { id: 'scifi', name: 'Ficção Científica' },
  { id: 'thriller', name: 'Suspense' },
];

export function Categories({ onMediaClick }: CategoriesProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [media, setMedia] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadMedia() {
      setLoading(true);
      try {
        let data: Media[] = [];

        switch (selectedCategory) {
          case 'all':
            data = await getTrending();
            break;
          case 'movies':
            data = await getPopularMovies();
            break;
          case 'series':
            data = await getPopularSeries();
            break;
          case 'action':
            const actionMovies = await getMoviesByGenre(genreIds.action);
            const actionSeries = await getSeriesByGenre(genreIds.action);
            data = [...actionMovies, ...actionSeries];
            break;
          case 'comedy':
            const comedyMovies = await getMoviesByGenre(genreIds.comedy);
            const comedySeries = await getSeriesByGenre(genreIds.comedy);
            data = [...comedyMovies, ...comedySeries];
            break;
          case 'drama':
            const dramaMovies = await getMoviesByGenre(genreIds.drama);
            const dramaSeries = await getSeriesByGenre(genreIds.drama);
            data = [...dramaMovies, ...dramaSeries];
            break;
          case 'scifi':
            const scifiMovies = await getMoviesByGenre(genreIds.scifi);
            const scifiSeries = await getSeriesByGenre(genreIds.scifi);
            data = [...scifiMovies, ...scifiSeries];
            break;
          case 'thriller':
            const thrillerMovies = await getMoviesByGenre(genreIds.thriller);
            const thrillerSeries = await getSeriesByGenre(genreIds.thriller);
            data = [...thrillerMovies, ...thrillerSeries];
            break;
        }

        setMedia(data);
      } catch (error) {
        console.error('Error loading category media:', error);
      } finally {
        setLoading(false);
      }
    }

    loadMedia();
  }, [selectedCategory]);

  return (
    <div className="min-h-screen bg-black p-4">
      <h1 className="text-white mb-4">Categorias</h1>
      
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-4 mb-6">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === cat.id
                ? 'bg-red-600 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>
      
      {loading ? (
        <div className="text-center py-16">
          <p className="text-gray-400">Carregando...</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {media.map((item) => (
            <MediaCard
              key={item.id}
              media={item}
              onClick={() => onMediaClick(item)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/BottomNav.tsx`

```typescript
import { Home, SearchIcon, Grid3x3 } from 'lucide-react';

interface BottomNavProps {
  currentView: 'home' | 'search' | 'categories' | 'details';
  onNavigate: (view: 'home' | 'search' | 'categories') => void;
}

export function BottomNav({ currentView, onNavigate }: BottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 px-4 py-3 safe-area-inset-bottom">
      <div className="flex justify-around items-center">
        <button
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'home' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <Home className="w-6 h-6" />
          <span className="text-xs">Início</span>
        </button>
        
        <button
          onClick={() => onNavigate('search')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'search' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <SearchIcon className="w-6 h-6" />
          <span className="text-xs">Buscar</span>
        </button>
        
        <button
          onClick={() => onNavigate('categories')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'categories' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <Grid3x3 className="w-6 h-6" />
          <span className="text-xs">Categorias</span>
        </button>
      </div>
    </div>
  );
}
```

---

## 📄 ARQUIVO: `src/components/ui/button.tsx`

```typescript
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive:
          "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
```

---

## 📄 ARQUIVO: `src/components/ui/utils.ts`

```typescript
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

---

## 📄 ARQUIVO: `src/styles/globals.css`

```css
@custom-variant dark (&:is(.dark *));

:root {
  --font-size: 16px;
  --background: #ffffff;
  --foreground: oklch(0.145 0 0);
  --card: #ffffff;
  --card-foreground: oklch(0.145 0 0);
  --popover: oklch(1 0 0);
  --popover-foreground: oklch(0.145 0 0);
  --primary: #030213;
  --primary-foreground: oklch(1 0 0);
  --secondary: oklch(0.95 0.0058 264.53);
  --secondary-foreground: #030213;
  --muted: #ececf0;
  --muted-foreground: #717182;
  --accent: #e9ebef;
  --accent-foreground: #030213;
  --destructive: #d4183d;
  --destructive-foreground: #ffffff;
  --border: rgba(0, 0, 0, 0.1);
  --input: transparent;
  --input-background: #f3f3f5;
  --switch-background: #cbced4;
  --font-weight-medium: 500;
  --font-weight-normal: 400;
  --ring: oklch(0.708 0 0);
  --chart-1: oklch(0.646 0.222 41.116);
  --chart-2: oklch(0.6 0.118 184.704);
  --chart-3: oklch(0.398 0.07 227.392);
  --chart-4: oklch(0.828 0.189 84.429);
  --chart-5: oklch(0.769 0.188 70.08);
  --radius: 0.625rem;
  --sidebar: oklch(0.985 0 0);
  --sidebar-foreground: oklch(0.145 0 0);
  --sidebar-primary: #030213;
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.97 0 0);
  --sidebar-accent-foreground: oklch(0.205 0 0);
  --sidebar-border: oklch(0.922 0 0);
  --sidebar-ring: oklch(0.708 0 0);
}

.dark {
  --background: oklch(0.145 0 0);
  --foreground: oklch(0.985 0 0);
  --card: oklch(0.145 0 0);
  --card-foreground: oklch(0.985 0 0);
  --popover: oklch(0.145 0 0);
  --popover-foreground: oklch(0.985 0 0);
  --primary: oklch(0.985 0 0);
  --primary-foreground: oklch(0.205 0 0);
  --secondary: oklch(0.269 0 0);
  --secondary-foreground: oklch(0.985 0 0);
  --muted: oklch(0.269 0 0);
  --muted-foreground: oklch(0.708 0 0);
  --accent: oklch(0.269 0 0);
  --accent-foreground: oklch(0.985 0 0);
  --destructive: oklch(0.396 0.141 25.723);
  --destructive-foreground: oklch(0.637 0.237 25.331);
  --border: oklch(0.269 0 0);
  --input: oklch(0.269 0 0);
  --ring: oklch(0.439 0 0);
  --font-weight-medium: 500;
  --font-weight-normal: 400;
  --chart-1: oklch(0.488 0.243 264.376);
  --chart-2: oklch(0.696 0.17 162.48);
  --chart-3: oklch(0.769 0.188 70.08);
  --chart-4: oklch(0.627 0.265 303.9);
  --chart-5: oklch(0.645 0.246 16.439);
  --sidebar: oklch(0.205 0 0);
  --sidebar-foreground: oklch(0.985 0 0);
  --sidebar-primary: oklch(0.488 0.243 264.376);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.269 0 0);
  --sidebar-accent-foreground: oklch(0.985 0 0);
  --sidebar-border: oklch(0.269 0 0);
  --sidebar-ring: oklch(0.439 0 0);
}

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  --color-border: var(--border);
  --color-input: var(--input);
  --color-input-background: var(--input-background);
  --color-switch-background: var(--switch-background);
  --color-ring: var(--ring);
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);
  --color-sidebar: var(--sidebar);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-ring: var(--sidebar-ring);
}

@layer base {
  * {
    @apply border-border outline-ring/50;
  }

  body {
    @apply bg-background text-foreground;
  }
}

/**
 * Base typography. This is not applied to elements which have an ancestor with a Tailwind text class.
 */
@layer base {
  :where(:not(:has([class*=' text-']), :not(:has([class^='text-'])))) {
    h1 {
      font-size: var(--text-2xl);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    h2 {
      font-size: var(--text-xl);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    h3 {
      font-size: var(--text-lg);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    h4 {
      font-size: var(--text-base);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    p {
      font-size: var(--text-base);
      font-weight: var(--font-weight-normal);
      line-height: 1.5;
    }

    label {
      font-size: var(--text-base);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    button {
      font-size: var(--text-base);
      font-weight: var(--font-weight-medium);
      line-height: 1.5;
    }

    input {
      font-size: var(--text-base);
      font-weight: var(--font-weight-normal);
      line-height: 1.5;
    }
  }
}

html {
  font-size: var(--font-size);
}

/* Hide scrollbar for mobile-like scroll experience */
.scrollbar-hide {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

.scrollbar-hide::-webkit-scrollbar {
  display: none;
}

/* Safe area inset for mobile devices */
.safe-area-inset-bottom {
  padding-bottom: env(safe-area-inset-bottom);
}
```

---

## 🚀 PRÓXIMOS PASSOS - COMO RODAR O PROJETO

### 1. Abra o terminal na pasta `dutv-app`

### 2. Instale as dependências:
```bash
npm install
```

### 3. Rode o projeto localmente:
```bash
npm run dev
```

### 4. Abra no navegador:
```
http://localhost:3000
```

---

## 📤 FAZER DEPLOY NO VERCEL

### 1. Crie um repositório no GitHub:
- Vá em: https://github.com/new
- Nome: `dutv-app`
- Faça upload de todos os arquivos

### 2. Deploy no Vercel:
- Acesse: https://vercel.com
- Login com GitHub
- "Add New" > "Project"
- Selecione `dutv-app`
- Configure:
  - Framework: **Vite**
  - Build: `npm run build`
  - Output: `dist`
- Clique em **Deploy**

### 3. Pronto! 🎉
Você terá seu link: `https://dutv-app.vercel.app`

---

## 📱 INSTALAR COMO APP

Depois do deploy, no celular Android:
1. Abra o link no Chrome
2. Menu (3 pontos)
3. "Adicionar à tela inicial"
4. Pronto! App instalado! 🎬

---

**🎬 Aproveite seu DuTV! 🍿**
