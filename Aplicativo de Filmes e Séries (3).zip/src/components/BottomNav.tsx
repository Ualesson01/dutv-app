import { Home, SearchIcon, Grid3x3 } from 'lucide-react';

interface BottomNavProps {
  currentView: 'home' | 'search' | 'categories' | 'details';
  onNavigate: (view: 'home' | 'search' | 'categories') => void;
}

export function BottomNav({ currentView, onNavigate }: BottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 px-4 py-3 safe-area-inset-bottom">
      <div className="flex justify-around items-center">
        <button
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'home' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <Home className="w-6 h-6" />
          <span className="text-xs">Início</span>
        </button>
        
        <button
          onClick={() => onNavigate('search')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'search' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <SearchIcon className="w-6 h-6" />
          <span className="text-xs">Buscar</span>
        </button>
        
        <button
          onClick={() => onNavigate('categories')}
          className={`flex flex-col items-center gap-1 ${
            currentView === 'categories' ? 'text-red-600' : 'text-gray-400'
          }`}
        >
          <Grid3x3 className="w-6 h-6" />
          <span className="text-xs">Categorias</span>
        </button>
      </div>
    </div>
  );
}
