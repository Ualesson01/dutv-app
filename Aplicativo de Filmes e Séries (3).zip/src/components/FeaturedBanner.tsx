import { Play, Info } from 'lucide-react';
import { Media } from '../App';
import { Button } from './ui/button';

interface FeaturedBannerProps {
  media: Media;
  onPlay: () => void;
}

export function FeaturedBanner({ media, onPlay }: FeaturedBannerProps) {
  return (
    <div className="relative h-[500px] w-full">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${media.backdrop})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <span className="px-2 py-1 bg-red-600 rounded">{media.type === 'movie' ? 'FILME' : 'SÉRIE'}</span>
          <span>{media.year}</span>
          <span>•</span>
          <span>{media.duration}</span>
        </div>
        
        <h1 className="text-white max-w-md">{media.title}</h1>
        
        <p className="text-gray-300 text-sm max-w-md line-clamp-3">
          {media.description}
        </p>
        
        <div className="flex gap-3">
          <Button className="flex-1 bg-white text-black hover:bg-gray-200" onClick={onPlay}>
            <Play className="w-5 h-5 mr-2 fill-current" />
            Assistir
          </Button>
          <Button variant="outline" className="flex-1 bg-gray-800/80 text-white border-gray-600 hover:bg-gray-700" onClick={onPlay}>
            <Info className="w-5 h-5 mr-2" />
            Detalhes
          </Button>
        </div>
      </div>
    </div>
  );
}
