import { Media } from '../App';
import { MediaCard } from './MediaCard';

interface MediaCarouselProps {
  title: string;
  media: Media[];
  onMediaClick: (media: Media) => void;
}

export function MediaCarousel({ title, media, onMediaClick }: MediaCarouselProps) {
  return (
    <div className="space-y-3">
      <h2 className="text-white px-1">{title}</h2>
      
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
        {media.map((item) => (
          <MediaCard
            key={item.id}
            media={item}
            onClick={() => onMediaClick(item)}
          />
        ))}
      </div>
    </div>
  );
}
