import { useState, useEffect } from 'react';
import { SearchIcon, X } from 'lucide-react';
import { Media } from '../App';
import { searchMedia, getTrending } from '../services/tmdb';
import { MediaCard } from './MediaCard';

interface SearchProps {
  onMediaClick: (media: Media) => void;
}

export function Search({ onMediaClick }: SearchProps) {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Media[]>([]);
  const [popular, setPopular] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadPopular() {
      const data = await getTrending();
      setPopular(data.slice(0, 9));
    }
    loadPopular();
  }, []);

  useEffect(() => {
    const delaySearch = setTimeout(async () => {
      if (query.trim()) {
        setLoading(true);
        const results = await searchMedia(query);
        setSearchResults(results);
        setLoading(false);
      } else {
        setSearchResults([]);
      }
    }, 500);

    return () => clearTimeout(delaySearch);
  }, [query]);

  return (
    <div className="min-h-screen bg-black p-4">
      <div className="sticky top-0 bg-black pb-4 z-10">
        <h1 className="text-white mb-4">Buscar</h1>
        
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Filmes, séries, gêneros..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-gray-900 text-white pl-11 pr-11 py-3 rounded-lg outline-none focus:ring-2 focus:ring-red-600"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-800 rounded-full"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-16">
          <p className="text-gray-400">Buscando...</p>
        </div>
      ) : query.trim() ? (
        searchResults.length > 0 ? (
          <div className="grid grid-cols-3 gap-3 pt-4">
            {searchResults.map((media) => (
              <MediaCard
                key={media.id}
                media={media}
                onClick={() => onMediaClick(media)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-gray-400">Nenhum resultado encontrado para "{query}"</p>
          </div>
        )
      ) : (
        <div className="space-y-6 pt-4">
          <div>
            <h2 className="text-white mb-3">Populares</h2>
            <div className="grid grid-cols-3 gap-3">
              {popular.map((media) => (
                <MediaCard
                  key={media.id}
                  media={media}
                  onClick={() => onMediaClick(media)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}