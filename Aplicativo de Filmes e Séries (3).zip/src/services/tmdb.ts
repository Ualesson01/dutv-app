import { Media } from '../App';

const TMDB_API_KEY = '3f70231d1356c2cdc9fe0fce9419c773';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';

interface TMDBMovie {
  id: number;
  title?: string;
  name?: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  genre_ids: number[];
  overview: string;
  poster_path: string;
  backdrop_path: string;
  media_type?: string;
}

interface TMDBGenre {
  id: number;
  name: string;
}

const genreMap: { [key: number]: string } = {
  28: 'Ação',
  12: 'Aventura',
  16: 'Animação',
  35: 'Comédia',
  80: 'Crime',
  99: 'Documentário',
  18: 'Drama',
  10751: 'Família',
  14: 'Fantasia',
  36: 'História',
  27: 'Terror',
  10402: 'Música',
  9648: 'Mistério',
  10749: 'Romance',
  878: 'Ficção Científica',
  10770: 'Cinema TV',
  53: 'Suspense',
  10752: 'Guerra',
  37: 'Faroeste',
  10759: 'Ação e Aventura',
  10762: 'Kids',
  10763: 'Notícias',
  10764: 'Reality',
  10765: 'Sci-Fi & Fantasy',
  10766: 'Novela',
  10767: 'Talk Show',
  10768: 'Guerra & Política',
};

function convertTMDBToMedia(item: TMDBMovie, type: 'movie' | 'series'): Media {
  const title = item.title || item.name || 'Sem título';
  const year = item.release_date
    ? new Date(item.release_date).getFullYear()
    : item.first_air_date
    ? new Date(item.first_air_date).getFullYear()
    : 2024;
  
  const genres = item.genre_ids
    .map(id => genreMap[id])
    .filter(Boolean)
    .slice(0, 3);

  return {
    id: item.id,
    title,
    type,
    year,
    rating: Math.round(item.vote_average * 10) / 10,
    duration: type === 'movie' ? '2h' : '1 temporada',
    genre: genres,
    description: item.overview || 'Descrição não disponível.',
    imageUrl: item.poster_path
      ? `${TMDB_IMAGE_BASE_URL}/w500${item.poster_path}`
      : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=500',
    backdrop: item.backdrop_path
      ? `${TMDB_IMAGE_BASE_URL}/original${item.backdrop_path}`
      : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=1920',
  };
}

async function fetchFromTMDB(endpoint: string): Promise<any> {
  const url = `${TMDB_BASE_URL}${endpoint}${endpoint.includes('?') ? '&' : '?'}api_key=${TMDB_API_KEY}&language=pt-BR`;
  
  const response = await fetch(url);
  
  if (!response.ok) {
    throw new Error(`TMDB API Error: ${response.status}`);
  }
  
  return response.json();
}

export async function getTrending(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/trending/all/week');
    return data.results.map((item: TMDBMovie) => 
      convertTMDBToMedia(item, item.media_type === 'tv' ? 'series' : 'movie')
    );
  } catch (error) {
    console.error('Error fetching trending:', error);
    return [];
  }
}

export async function getPopularMovies(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/movie/popular');
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'movie'));
  } catch (error) {
    console.error('Error fetching popular movies:', error);
    return [];
  }
}

export async function getPopularSeries(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/tv/popular');
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'series'));
  } catch (error) {
    console.error('Error fetching popular series:', error);
    return [];
  }
}

export async function getTopRated(): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB('/movie/top_rated');
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'movie'));
  } catch (error) {
    console.error('Error fetching top rated:', error);
    return [];
  }
}

export async function getMoviesByGenre(genreId: number): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/discover/movie?with_genres=${genreId}`);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'movie'));
  } catch (error) {
    console.error('Error fetching movies by genre:', error);
    return [];
  }
}

export async function getSeriesByGenre(genreId: number): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/discover/tv?with_genres=${genreId}`);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, 'series'));
  } catch (error) {
    console.error('Error fetching series by genre:', error);
    return [];
  }
}

export async function searchMedia(query: string): Promise<Media[]> {
  try {
    const data = await fetchFromTMDB(`/search/multi?query=${encodeURIComponent(query)}`);
    return data.results
      .filter((item: TMDBMovie) => item.media_type === 'movie' || item.media_type === 'tv')
      .map((item: TMDBMovie) => 
        convertTMDBToMedia(item, item.media_type === 'tv' ? 'series' : 'movie')
      );
  } catch (error) {
    console.error('Error searching media:', error);
    return [];
  }
}

export async function getMediaDetails(id: number, type: 'movie' | 'series'): Promise<Media | null> {
  try {
    const endpoint = type === 'movie' ? `/movie/${id}` : `/tv/${id}`;
    const data = await fetchFromTMDB(endpoint);
    
    const title = data.title || data.name || 'Sem título';
    const year = data.release_date
      ? new Date(data.release_date).getFullYear()
      : data.first_air_date
      ? new Date(data.first_air_date).getFullYear()
      : 2024;
    
    const genres = data.genres?.map((g: TMDBGenre) => g.name) || [];
    
    const duration = type === 'movie'
      ? data.runtime
        ? `${Math.floor(data.runtime / 60)}h ${data.runtime % 60}min`
        : '2h'
      : data.number_of_seasons
      ? `${data.number_of_seasons} ${data.number_of_seasons === 1 ? 'temporada' : 'temporadas'}`
      : '1 temporada';

    return {
      id: data.id,
      title,
      type,
      year,
      rating: Math.round(data.vote_average * 10) / 10,
      duration,
      genre: genres,
      description: data.overview || 'Descrição não disponível.',
      imageUrl: data.poster_path
        ? `${TMDB_IMAGE_BASE_URL}/w500${data.poster_path}`
        : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=500',
      backdrop: data.backdrop_path
        ? `${TMDB_IMAGE_BASE_URL}/original${data.backdrop_path}`
        : 'https://images.unsplash.com/photo-1640127249308-098702574176?w=1920',
    };
  } catch (error) {
    console.error('Error fetching media details:', error);
    return null;
  }
}

export async function getSimilarMedia(id: number, type: 'movie' | 'series'): Promise<Media[]> {
  try {
    const endpoint = type === 'movie' ? `/movie/${id}/similar` : `/tv/${id}/similar`;
    const data = await fetchFromTMDB(endpoint);
    return data.results.map((item: TMDBMovie) => convertTMDBToMedia(item, type));
  } catch (error) {
    console.error('Error fetching similar media:', error);
    return [];
  }
}

export const genreIds = {
  action: 28,
  comedy: 35,
  drama: 18,
  scifi: 878,
  thriller: 53,
  romance: 10749,
  animation: 16,
  documentary: 99,
};