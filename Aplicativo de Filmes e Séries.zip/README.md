
  # Aplicativo de Filmes e Séries

  This is a code bundle for Aplicativo de Filmes e Séries. The original project is available at https://www.figma.com/design/BJFuKCRvNRDb5hjrKCeHsr/Aplicativo-de-Filmes-e-S%C3%A9ries.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  