# 🚀 Instruções de Deploy do DuTV

## Método 1: Vercel (Mais Fácil e Recomendado) ⭐

### Passo a Passo:

1. **Criar conta no Vercel**
   - Acesse: https://vercel.com
   - Clique em "Sign Up"
   - Faça login com sua conta do GitHub

2. **Preparar o código**
   - Faça download de todos os arquivos do projeto
   - Crie um repositório no GitHub:
     - Acesse https://github.com/new
     - Nome: `dutv-app`
     - Clique em "Create repository"
   - Faça upload dos arquivos para o repositório

3. **Deploy no Vercel**
   - No Vercel, clique em "Add New" > "Project"
   - Clique em "Import Git Repository"
   - Selecione o repositório `dutv-app`
   - Configure:
     - **Framework Preset**: Vite
     - **Build Command**: `npm run build`
     - **Output Directory**: `dist`
     - **Install Command**: `npm install`
   - Clique em "Deploy"
   - Aguarde 2-3 minutos ⏱️

4. **Pronto! 🎉**
   - Você receberá um link tipo: `https://dutv-app.vercel.app`
   - Compartilhe este link!

---

## Método 2: Netlify (Alternativa)

1. **Criar conta**
   - Acesse: https://netlify.com
   - Faça login com GitHub

2. **Deploy**
   - Clique em "Add new site" > "Import an existing project"
   - Conecte com GitHub e selecione o repositório
   - Configure:
     - **Build command**: `npm run build`
     - **Publish directory**: `dist`
   - Clique em "Deploy site"

3. **Link pronto!**
   - Você receberá: `https://dutv-app.netlify.app`

---

## Método 3: Deploy Manual (Sem GitHub)

### Se você não quer usar GitHub:

1. **Build local**
   ```bash
   npm install
   npm run build
   ```

2. **Upload da pasta `dist`**
   - No Netlify: Arraste a pasta `dist` direto no site
   - Ou use: https://app.netlify.com/drop

---

## 📱 Como Instalar como App no Celular

Após o deploy, qualquer pessoa pode instalar o DuTV:

### Android (Chrome):
1. Abra o link no Chrome
2. Toque no menu (3 pontos)
3. Selecione "Adicionar à tela inicial"
4. Confirme
5. Ícone do DuTV aparecerá na tela inicial! 📱

### iPhone (Safari):
1. Abra o link no Safari
2. Toque no ícone de compartilhar
3. Selecione "Adicionar à Tela de Início"
4. Confirme
5. Pronto! 📱

---

## ⚙️ Configurações Importantes

### Para funcionamento completo, você precisa:

✅ Chave de API do TMDB (já configurada)
✅ Node.js instalado (para build local)
✅ Conta no Vercel ou Netlify (gratuita)

---

## 🆘 Problemas Comuns

**"Build failed"**
- Certifique-se de que todos os arquivos foram enviados
- Verifique se o `package.json` está correto

**"API not working"**
- Verifique se a chave do TMDB está no arquivo `/services/tmdb.ts`
- Chave atual: `3f70231d1356c2cdc9fe0fce9419c773`

**"Images not loading"**
- Aguarde alguns minutos após o deploy
- Verifique sua conexão com internet

---

## 📞 Suporte

- TMDB API Docs: https://developers.themoviedb.org/3
- Vercel Docs: https://vercel.com/docs
- Netlify Docs: https://docs.netlify.com

---

**🎬 Bom deploy! Aproveite seu DuTV! 🍿**
