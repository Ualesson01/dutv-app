# DuTV - Aplicativo de Filmes e Séries

Aplicativo web de streaming integrado com a API do TMDB (The Movie Database).

## 🚀 Funcionalidades

- ✅ Filmes e séries em alta da semana
- ✅ Conteúdo popular atualizado
- ✅ Busca em tempo real
- ✅ Detalhes completos com duração e temporadas reais
- ✅ Recomendações similares
- ✅ Filtros por categorias (Ação, Comédia, Drama, etc.)
- ✅ Imagens e pôsteres de alta qualidade
- ✅ Interface otimizada para mobile
- ✅ PWA - Instalável como app

## 📱 Como Fazer Deploy

### Opção 1: Vercel (Recomendado)

1. Acesse https://vercel.com e faça login com GitHub
2. Clique em "Add New" > "Project"
3. Importe este repositório
4. Configure:
   - Framework Preset: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Clique em "Deploy"
6. Pronto! Seu link estará disponível

### Opção 2: Netlify

1. Acesse https://netlify.com e faça login
2. Arraste a pasta do projeto ou conecte com GitHub
3. Configure:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Clique em "Deploy"

### Opção 3: GitHub Pages

1. No arquivo `vite.config.ts`, adicione: `base: '/nome-do-repositorio/'`
2. Execute: `npm run build`
3. Execute: `npm run deploy` (se configurado) ou faça upload manual da pasta `dist`

## 🔑 API Key

A chave de API do TMDB já está configurada no arquivo `/services/tmdb.ts`

## 💻 Desenvolvimento Local

```bash
npm install
npm run dev
```

## 📦 Build para Produção

```bash
npm run build
```

## 🌐 Instalação como PWA

Após o deploy, usuários podem instalar o DuTV:
- **Android**: Abrir no Chrome > Menu > "Adicionar à tela inicial"
- **iOS**: Abrir no Safari > Compartilhar > "Adicionar à Tela de Início"

---

Desenvolvido com React, TypeScript, Tailwind CSS e TMDB API
