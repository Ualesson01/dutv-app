import { useState, useEffect } from 'react';
import { Media } from '../App';
import {
  getTrending,
  getPopularMovies,
  getPopularSeries,
  getMoviesByGenre,
  getSeriesByGenre,
  genreIds,
} from '../services/tmdb';
import { MediaCard } from './MediaCard';

interface CategoriesProps {
  onMediaClick: (media: Media) => void;
}

const categories = [
  { id: 'all', name: 'Todos' },
  { id: 'movies', name: 'Filmes' },
  { id: 'series', name: 'Séries' },
  { id: 'action', name: 'Ação' },
  { id: 'comedy', name: 'Comédia' },
  { id: 'drama', name: 'Drama' },
  { id: 'scifi', name: 'Ficção Científica' },
  { id: 'thriller', name: 'Suspense' },
];

export function Categories({ onMediaClick }: CategoriesProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [media, setMedia] = useState<Media[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadMedia() {
      setLoading(true);
      try {
        let data: Media[] = [];

        switch (selectedCategory) {
          case 'all':
            data = await getTrending();
            break;
          case 'movies':
            data = await getPopularMovies();
            break;
          case 'series':
            data = await getPopularSeries();
            break;
          case 'action':
            const actionMovies = await getMoviesByGenre(genreIds.action);
            const actionSeries = await getSeriesByGenre(genreIds.action);
            data = [...actionMovies, ...actionSeries];
            break;
          case 'comedy':
            const comedyMovies = await getMoviesByGenre(genreIds.comedy);
            const comedySeries = await getSeriesByGenre(genreIds.comedy);
            data = [...comedyMovies, ...comedySeries];
            break;
          case 'drama':
            const dramaMovies = await getMoviesByGenre(genreIds.drama);
            const dramaSeries = await getSeriesByGenre(genreIds.drama);
            data = [...dramaMovies, ...dramaSeries];
            break;
          case 'scifi':
            const scifiMovies = await getMoviesByGenre(genreIds.scifi);
            const scifiSeries = await getSeriesByGenre(genreIds.scifi);
            data = [...scifiMovies, ...scifiSeries];
            break;
          case 'thriller':
            const thrillerMovies = await getMoviesByGenre(genreIds.thriller);
            const thrillerSeries = await getSeriesByGenre(genreIds.thriller);
            data = [...thrillerMovies, ...thrillerSeries];
            break;
        }

        setMedia(data);
      } catch (error) {
        console.error('Error loading category media:', error);
      } finally {
        setLoading(false);
      }
    }

    loadMedia();
  }, [selectedCategory]);

  return (
    <div className="min-h-screen bg-black p-4">
      <h1 className="text-white mb-4">Categorias</h1>
      
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-4 mb-6">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              selectedCategory === cat.id
                ? 'bg-red-600 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>
      
      {loading ? (
        <div className="text-center py-16">
          <p className="text-gray-400">Carregando...</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {media.map((item) => (
            <MediaCard
              key={item.id}
              media={item}
              onClick={() => onMediaClick(item)}
            />
          ))}
        </div>
      )}
    </div>
  );
}