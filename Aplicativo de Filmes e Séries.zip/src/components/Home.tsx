import { Media } from '../App';
import { MediaCarousel } from './MediaCarousel';
import { FeaturedBanner } from './FeaturedBanner';
import { useEffect, useState } from 'react';
import {
  getTrending,
  getPopularMovies,
  getPopularSeries,
  getMoviesByGenre,
  genreIds,
} from '../services/tmdb';

interface HomeProps {
  onMediaClick: (media: Media) => void;
}

export function Home({ onMediaClick }: HomeProps) {
  const [trending, setTrending] = useState<Media[]>([]);
  const [movies, setMovies] = useState<Media[]>([]);
  const [series, setSeries] = useState<Media[]>([]);
  const [action, setAction] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const [trendingData, moviesData, seriesData, actionData] = await Promise.all([
          getTrending(),
          getPopularMovies(),
          getPopularSeries(),
          getMoviesByGenre(genreIds.action),
        ]);

        setTrending(trendingData.slice(0, 8));
        setMovies(moviesData.slice(0, 8));
        setSeries(seriesData.slice(0, 8));
        setAction(actionData.slice(0, 8));
      } catch (error) {
        console.error('Error loading home data:', error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const featured = trending[0];

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Carregando...</div>
      </div>
    );
  }

  if (!featured) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-center px-4">
          <p className="mb-2">Erro ao carregar conteúdo</p>
          <p className="text-sm text-gray-400">Verifique sua chave de API do TMDB</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <FeaturedBanner media={featured} onPlay={() => onMediaClick(featured)} />
      
      <div className="px-4 space-y-6 -mt-20 relative z-10">
        {trending.length > 0 && (
          <MediaCarousel
            title="Em Alta"
            media={trending}
            onMediaClick={onMediaClick}
          />
        )}
        
        {movies.length > 0 && (
          <MediaCarousel
            title="Filmes Populares"
            media={movies}
            onMediaClick={onMediaClick}
          />
        )}
        
        {series.length > 0 && (
          <MediaCarousel
            title="Séries em Destaque"
            media={series}
            onMediaClick={onMediaClick}
          />
        )}
        
        {action.length > 0 && (
          <MediaCarousel
            title="Ação e Aventura"
            media={action}
            onMediaClick={onMediaClick}
          />
        )}
      </div>
    </div>
  );
}