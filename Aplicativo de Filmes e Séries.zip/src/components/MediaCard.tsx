import { Star } from 'lucide-react';
import { Media } from '../App';

interface MediaCardProps {
  media: Media;
  onClick: () => void;
}

export function MediaCard({ media, onClick }: MediaCardProps) {
  return (
    <div
      className="flex-shrink-0 w-32 cursor-pointer transition-transform hover:scale-105"
      onClick={onClick}
    >
      <div className="relative rounded-lg overflow-hidden bg-gray-800 aspect-[2/3]">
        <img
          src={media.imageUrl}
          alt={media.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-black/70 px-2 py-1 rounded flex items-center gap-1">
          <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
          <span className="text-white text-xs">{media.rating}</span>
        </div>
      </div>
      <p className="text-white text-sm mt-2 line-clamp-2">{media.title}</p>
      <p className="text-gray-400 text-xs">{media.year}</p>
    </div>
  );
}
