import { ArrowLeft, Play, Plus, Share2, Star } from 'lucide-react';
import { Media } from '../App';
import { Button } from './ui/button';
import { MediaCard } from './MediaCard';
import { useEffect, useState } from 'react';
import { getMediaDetails, getSimilarMedia } from '../services/tmdb';

interface MovieDetailsProps {
  media: Media;
  onBack: () => void;
}

export function MovieDetails({ media: initialMedia, onBack }: MovieDetailsProps) {
  const [media, setMedia] = useState(initialMedia);
  const [similar, setSimilar] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDetails() {
      setLoading(true);
      try {
        const [detailsData, similarData] = await Promise.all([
          getMediaDetails(initialMedia.id, initialMedia.type),
          getSimilarMedia(initialMedia.id, initialMedia.type),
        ]);

        if (detailsData) {
          setMedia(detailsData);
        }
        setSimilar(similarData.slice(0, 6));
      } catch (error) {
        console.error('Error loading details:', error);
      } finally {
        setLoading(false);
      }
    }

    loadDetails();
  }, [initialMedia.id, initialMedia.type]);

  return (
    <div className="min-h-screen bg-black">
      <div className="relative">
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-20 p-2 bg-black/50 rounded-full text-white"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        <div className="relative h-[300px]">
          <img
            src={media.backdrop}
            alt={media.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        </div>
        
        <div className="relative -mt-16 px-6 space-y-4">
          <h1 className="text-white">{media.title}</h1>
          
          <div className="flex items-center gap-3 text-sm text-gray-300">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span>{media.rating}</span>
            </div>
            <span>•</span>
            <span>{media.year}</span>
            <span>•</span>
            <span>{media.duration}</span>
            <span>•</span>
            <span className="px-2 py-0.5 bg-gray-700 rounded text-xs">
              {media.type === 'movie' ? 'FILME' : 'SÉRIE'}
            </span>
          </div>
          
          {media.genre.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {media.genre.map((g, i) => (
                <span key={i} className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm">
                  {g}
                </span>
              ))}
            </div>
          )}
          
          <p className="text-gray-300 text-sm leading-relaxed">
            {media.description}
          </p>
          
          <div className="space-y-3 pt-4">
            <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
              <Play className="w-5 h-5 mr-2 fill-current" />
              Assistir Agora
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                <Plus className="w-5 h-5 mr-2" />
                Minha Lista
              </Button>
              <Button variant="outline" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                <Share2 className="w-5 h-5 mr-2" />
                Compartilhar
              </Button>
            </div>
          </div>
          
          {similar.length > 0 && (
            <div className="pt-8 space-y-3">
              <h2 className="text-white">Títulos Similares</h2>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-4">
                {similar.map((item) => (
                  <MediaCard
                    key={item.id}
                    media={item}
                    onClick={() => {}}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}